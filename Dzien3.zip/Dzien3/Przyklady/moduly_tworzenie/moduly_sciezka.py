import sys

# wypisuje ścieżki 'sys.path' to lista
print("scieżki ....")
for p in sys.path:
    print(p)
