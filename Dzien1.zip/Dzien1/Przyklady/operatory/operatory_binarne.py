x1 = 0b1001
x2 = 0b0011
print("binarne lub ", bin(x1 | x2))
print("binarne and ", bin(x1 & x2))
print("binarne xor ", bin(x1 ^ x2))
print()
x3 = 0b1000
print("przesuniecie bitowe w prawo ", bin(x3 >> 2))
print("przesuniecie bitowe w lewo  ", bin(x3 << 2))
